# C 模組第二版：規則、本地 AI 說明與報告（v2.1.0）

這批程式接收 B 提供的 `[SecurityEvent]`，**先由 Swift 固定規則判斷**，再用裝置端模型產生說明。模型不可用、生成失敗、取消或手動關閉 AI 時，改用固定規則說明。模型不會決定門檻、次數、狀態或風險等級。

> **驗證狀態（請先讀）**：這批程式**尚未在 Xcode 編譯，也尚未在 iPhone／模擬器執行**。製作環境沒有 Swift 編譯器。附上的 XCTest 是「待執行的測試」，不是通過紀錄。詳見文末「驗證狀態」。

---

## 1. 這一版實際改了什麼（與沒改什麼）

我逐一檢查了原 v2.0.0 的七份程式與 15 個測試。**沒有找到「確定會編譯失敗」的錯誤**（我沒有編譯器，無法確定，只能說原始碼檢查沒看到）。做的是下面這些有理由的修正；每一項都標明依據是「已重現」還是「預防／審閱發現」。

| # | 修改 | 依據 |
|---|---|---|
| 1 | `SecurityAnalyzer`：時間窗比較從 Double 秒改成**整數毫秒**；相同時間的事件用輸入順序決定先後 | 預防性加強。我用 Python 重現同一演算法，沒有重現「剛好 60 秒被排除」，所以**不是已確認的 bug**。規則語意不變；代價是毫秒以下的差異不會被區分 |
| 2 | 測試的時間字串改用整數運算組成，不再靠 `Date`→格式化器產生 | 舊測試用格式化器產生「60.001 秒」，我無法在這裡確認格式化器會不會截斷毫秒；改成字面字串就不必依賴這點 |
| 3 | 測試的「舊結果不得覆蓋新結果」改成可決定性等待：`ViewModel.waitForAllAnalysisTasks()` 與 stub 的 `waitUntilHolding()` | 舊測試只 `Task.yield()` 一次，無法保證舊任務已收尾，測試可能「沒測到東西也通過」 |
| 4 | 測試類別整個標 `@MainActor`；補上缺少的情境（見第 8 節） | 審閱：舊版逐方法標註，且 §13 的 22 項中有數項沒有對應測試（保存失敗、清除互不影響、空白輸出、舊檔解碼…） |
| 5 | 歷史檔讀不到時，分析後顯示「已保留舊檔、可先匯出、可手動清除」的具體訊息 | 審閱發現：舊版會被籠統的「未能保存」蓋掉 |
| 6 | 畫面：匯出檔綁定「準備它的那份報告」；新增「來源代號對照」完整區塊 | 審閱：避免報告改變後仍顯示舊匯出檔；§12 要求代號對照 |
| 7 | 畫面：`onChange` 改用依系統版本選擇的小工具 | iOS 17 起單參數寫法被標為棄用（只是警告）；本專案最低 iOS 16 |
| 8 | `@Generable` 結構加 `nonisolated`；錯誤型別的 `print` 只在 Debug 輸出 | 因應「Default Actor Isolation」可能設為 MainActor（見第 6 節）；避免 Release 輸出 |
| 9 | `moduleVersion` 升為 `2.1.0` | 只標示產生報告的程式版本 |

**完全沒改**：規則 ID／60 秒／>10／`test_private_file.txt`、每來源最多一筆 finding、AI 只收數字與 S01 代號、報告外層 camelCase＋`ruleResult` 內 snake_case、`schemaVersion "1.0"`。**舊的 reports.json（2.0.0 產生）可直接讀取**，測試中有一份舊格式 JSON 的解碼檢查。

---

## 2. 檔案清單

| 檔案 | 這一版處理 | 放哪裡 |
|---|---|---|
| `Source/SecurityAnalyzer.swift` | **修改**（整數毫秒） | App target |
| `Source/SecurityAIModels.swift` | **修改**（只有版本號） | App target |
| `Source/LocalSecurityAI.swift` | **修改**（`nonisolated`、Debug 輸出） | App target |
| `Source/SecurityAnalysisViewModel.swift` | **修改**（等待接口、歷史訊息） | App target |
| `Source/SecurityReportStore.swift` | 沿用，內容與 2.0.0 相同 | App target |
| `Source/SecurityReportExporter.swift` | 沿用，內容與 2.0.0 相同 | App target |
| `Source/ContentView_CIntegration.swift` | **替換**既有 `ContentView.swift` 的內容 | App target |
| `Tests/SecurityModuleTests.swift` | **改寫** | 只加入 Unit Tests target |
| `C_Module_README.md` | 本文件 | 放儲存庫根目錄 |

不屬於 C、請保留 A／B 原檔：`SecurityEvent.swift`、`EventCollector.swift`、`EventStore.swift`、`TestFileService.swift`、App 入口檔。

---

## 3. 怎麼交給 B（一次整合，不用刪舊專案）

**你（Windows）**
1. 解壓縮 ZIP，用 VS Code 看或改檔案都可以。
2. 在你的 GitHub 儲存庫，用 ZIP 內的檔案**覆蓋**同名檔案（`SecurityAnalyzer`、`SecurityAIModels`、`LocalSecurityAI`、`SecurityAnalysisViewModel`、`ContentView_CIntegration`、`Tests/SecurityModuleTests`、README）。**不需要刪掉整個舊專案或舊儲存庫。**
3. 把儲存庫連結給 B，說「C 模組 2.1.0 整包更新，請依 README 一次整合並編譯」。你的部分到此完成。

**B（Mac／Xcode）**
1. 先建立工作分支或備份。
2. 保留 A／B 既有的四份檔案與 App 入口。
3. 用 ZIP 內檔案更新 C 的 Source；Target Membership 都勾**同一個 iOS App target**。
4. 把 `ContentView.swift` 的內容**整份換成** `ContentView_CIntegration.swift` 的內容。
5. 若專案裡另有 `EventDetailView`，只留一份（本包已包含）。
6. 建議 Xcode 26 以上、iOS 26 SDK 以上編譯（本地 AI 分支需要）。畫面最低 iOS 16。
7. Build → 修完編譯錯誤 → 再一次跑第 8 節的情境。
8. 跑測試：把 `Tests/SecurityModuleTests.swift` 加到 **Unit Tests target**，並把第二行 `@testable import AISecurityMonitor` 的 `AISecurityMonitor` 改成 App target 的 `PRODUCT_MODULE_NAME`（Build Settings 可查）。**這個名字是占位，我並不知道實際名稱。**

### 為什麼不能同時放兩份 ContentView
Swift 同一個 target 裡，同名型別只能定義一次。若 `ContentView.swift` 和 `ContentView_CIntegration.swift` 都在 target 裡，會出現 `Invalid redeclaration of 'ContentView'`。`EventDetailView` 同理。也不要另外加 App 入口，否則 `@main` 重複。

---

## 4. 不支援的裝置：備用說明是「正常狀態」

本地 AI 需要 iOS 26 以上、支援 Apple Intelligence 的裝置、已開啟 Apple Intelligence、模型已就緒。任何一項不符合，畫面會顯示原因並使用**固定規則說明**；規則結果不受影響。`#if canImport(FoundationModels)` 只代表「這個 SDK 編得過」，不代表舊裝置能跑 AI。

| 狀況 | 預期 |
|---|---|
| 關閉 AI 開關／空事件 | 固定規則說明，不呼叫模型 |
| 裝置不支援／Apple Intelligence 未開／模型未下載完 | 固定規則說明＋原因，可稍後按「重新檢查模型狀態」 |
| 生成失敗、取消、輸出空白 | 保留規則結果，改用固定規則說明 |
| 同一批事件再次分析（先前 AI 成功過） | 重用上一份 AI 說明並提示 |
| 等待中讀取新事件／清除／切換開關／進背景／按「停止等待」 | 舊任務失效；保留固定規則報告；舊回覆之後返回也不得覆蓋 |

「停止等待」會取消 Swift task 並使其結果失效，**不保證底層模型立即停止**。這版沒有強制逾時。

---

## 5. 規則（沒有改動）

1. 只計入 `action == "read"`、`result == "allowed"`、`target == "test_private_file.txt"`。
2. 依 `source` 分組；不同來源不相加。
3. 解析為真正時間（支援 `Z`、`+08:00`；亂序與混合時區先排序）。
4. 任意 60 秒內最大次數；**剛好 60 秒仍計入**，超過才排除。
5. 嚴格大於 10 才觸發：10 次不觸發、11 次觸發。風險固定 `medium`。
6. 這是歷史時間窗，不是「現在往前 60 秒」；模擬事件照常參與。
7. 符合計數條件的事件若時間缺時區或無法解析 → 回報 `eventID` 與錯誤，不呼叫 AI、不保存報告。不符合條件的事件不解析時間。

`allowed` 在本專案只代表「讀檔成功」，不是系統安全機制的授權稽核。`status` 只代表本規則，不代表已確認攻擊或全面安全。EventStore 目前最多保留 50 筆，更早的事件不在分析範圍。

---

## 6. Swift 設定（Concurrency）依賴點

專案的 Swift Language Mode、Strict Concurrency、Default Actor Isolation **尚未提供**。這批的設計：

- 協調層（`SecurityExplaining`、`LocalSecurityAI`、`SecurityAnalysisViewModel`、`SecurityReportStore`）與畫面都是 `@MainActor`；規則與資料型別不加標註，只被 MainActor 呼叫，**不跨 actor 傳遞**，所以沒有用 `@unchecked Sendable` 或 `nonisolated(unsafe)`。
- 依賴設定、可能需要 B 回報的地方：
  1. `LocalSecurityAI.swift` 的 `@Generable private nonisolated struct`：若 Default Actor Isolation = MainActor，`nonisolated` 是為了避免生成型別協定被推論成 MainActor。若 Xcode 對這一行報錯，請回傳完整錯誤。
  2. A 的 `SecurityEvent` 若在 Default Actor Isolation = MainActor 下被推論成 MainActor 隔離，C 的程式仍可用（全程在 MainActor）；但日後若要在背景執行緒分析，需要另外處理。
  3. 測試類別為 `@MainActor`；若你的工具鏈無法發現這種測試，請回傳 Test navigator 的畫面或錯誤。

---

## 7. 資料範圍

**送進模型的內容**：`SecurityAIContext` 的 JSON——事件總數、符合條件讀取數、失敗讀取數、排除數、模擬事件數、規則設定、觸發來源數、省略數，以及最多 8 個觸發來源的「來源代號（S01…）＋峰值次數」。**不含**原始來源名稱、target、時間字串、eventID、檔案內容、完整事件 JSON。有測試檢查這一點。

**匯出／歷史報告的內容**：版本、時間、規則結果、AI 統計、來源代號對照、說明來源與備用原因，以及**完整事件欄位**（含來源名稱）。**不含**實際讀取的檔案內容。匯出由使用者在分享表單選擇去處，程式不連網。

歷史存在 `Application Support/SecurityIR/reports.json`，最多 10 份，與 A 的 `events.json` 分開；清除事件不清歷史，清除歷史不清事件。

---

## 8. 一次集中驗證（待 B 在 Mac／裝置執行）

規則情境先**關閉 AI、清除事件**；真實 AI 情境再開啟。Debug build 提供「連續讀取測試檔 11 次」。

| 情境 | 操作或輸入 | 預期 |
|---|---|---|
| 空資料 | 清除→分析 | 0 筆、未觸發、固定規則說明 |
| 門檻 10 | 60 秒內成功讀取 10 次→分析 | 未觸發 |
| 門檻 11 | 清除→Debug 11 次→分析 | `TestApp`、峰值 11、觸發 |
| 失敗不計入 | 成功 10 次＋讀不存在檔 1 次 | 總事件 11、未觸發 |
| 更新失效 | 分析後再讀取或清除 | 舊結果清掉，需重新分析 |
| AI 不可用 | 不符合模型條件的環境分析 | 固定規則說明＋原因、不崩潰 |
| 真實 AI | 符合條件、開啟 AI→分析 | 標「本地 AI 說明」，規則數字正確 |
| 等待中更新／停止 | AI 生成中讀取新事件，或按「停止等待」 | 不被稍後回覆覆蓋、不持續轉圈 |
| 快取 | 同批事件完成後再分析 | 重用說明並提示 |
| 來源代號 | 分析完成後查看 | 「來源代號對照」與報告一致 |
| 歷史保存 | 分析→關閉重開 App | 歷史仍在；上限 10 份 |
| 匯出 | 準備→分享或儲存→用編輯器打開 | JSON 可解析，事件、規則、說明來源一致；報告換了就不再顯示舊分享按鈕 |

自動測試（XCTest，共 35 個方法）涵蓋：邊界（10／11、恰好 60 秒、60.001 秒、含小數秒、同秒多筆）、來源分組、亂序與混合時區、缺時區、AI 輸入隔離與 8 來源上限、空白輸出、舊格式報告解碼、JSON 往返、歷史上限／損壞保留／保存失敗、模型失敗／自行取消／停止等待／舊回覆不覆蓋、快取。

**stub 測試只驗證協調流程，不能代表 Apple 模型的真實推論或中文生成品質。**

---

## 9. 驗證狀態

**已實際執行**（在製作環境）
- 把規則的滑動視窗演算法移植成 Python，與暴力解比對 3000 組隨機資料，結果一致；並檢查 10／11、恰好 60 秒、60.001 秒、含小數秒等邊界。**這是演算法邏輯檢查，不是 Swift 執行。**
- 簡單的原始碼結構檢查：括號配對、無重複的頂層型別定義。**這不是編譯。**

**只做原始碼／文件檢查**
- 對照 Apple 官方文件頁：`SystemLanguageModel.availability` 與三種不可用原因（`deviceNotEligible`、`appleIntelligenceNotEnabled`、`modelNotReady`）、`LanguageModelSession.respond(to:generating:includeSchemaInPrompt:options:)` 的 `String` 版本（iOS 26 起）、以 `String` 建立 session 的官方範例。
- **官方頁面我沒能確認到的**：`GenerationOptions(temperature:)` 的初始化形式、`@Generable` 與 actor 隔離的互動。這些要靠編譯確認。
- 官方文件已出現 iOS 27 才有的新 overload（`respond(to:generating:options:contextOptions:metadata:)`）與 `LanguageModelError`。本包只用 iOS 26 就有的 API，並且**刻意不對任何錯誤列舉做模式比對**（生成失敗一律走備用路徑）。若用 iOS 27 SDK 編譯出現棄用警告或多載問題，請回傳完整錯誤。

**待 Xcode／裝置驗證**
- Swift 編譯、XCTest 實際通過、SwiftUI 操作、`ShareLink` 分享檔案、Foundation Models 真實推論與中文效果、離線使用（模型首次準備可能需要網路）。

---

## 10. 遇到編譯錯誤時請回傳

1. 完整錯誤文字（不要只說「不能跑」）。
2. Xcode 版本、SDK 版本、部署目標。
3. 發生錯誤的檔案與行號。
4. App target 與 Unit Tests target 的名稱，以及 `PRODUCT_MODULE_NAME`。
5. Build Settings：Swift Language Mode、Strict Concurrency Checking、Default Actor Isolation。

常見狀況：

| 錯誤或現象 | 處理 |
|---|---|
| `Invalid redeclaration of ContentView／EventDetailView` | 移除重複定義，只留 `ContentView_CIntegration.swift` 的內容 |
| `Cannot find 'SecurityAnalysisViewModel'` 等 | 確認新增檔案都在同一個 App target |
| `No such module 'AISecurityMonitor'`（測試檔） | 改成實際 `PRODUCT_MODULE_NAME`，且只加到 Tests target |
| 只有固定規則、沒有本地 AI | 先看畫面的模型狀態；SDK／系統／裝置／設定不符是預期行為 |
| 歷史讀取失敗 | 先匯出本次報告；舊檔保留；需要時再手動清除歷史 |
| 模型文字與規則數字不同 | 以規則為準；保留該報告作為調整提示詞的案例 |
| `SecurityEvent` 第一行是 `mport Foundation` | 修正為 `import Foundation` |

---

## 11. 已知限制

- 匯出的 JSON 先寫在系統暫存資料夾，由系統自行清理；程式沒有主動刪除。
- 歷史檔是「整份讀得進來或整份讀不進來」；只要有一份報告損壞，整個歷史都會被保留但不載入。
- 這版沒有模型逾時；只能手動停止等待。
- `#Preview` 需要支援該巨集的 Xcode。

## 12. 尚未完成（請勿描述為已完成）

目前只是可驗證的 Prototype：**App 內操作 → 事件紀錄 → 固定規則 → 本地 AI／固定規則說明 → 本機歷史報告 → 手動 JSON 匯出**。

- 「建議」只是文字建議，**沒有任何自動封鎖、刪除或阻擋行為**。
- 只分析這個 App 自己產生的事件，**不是整支 iPhone 或其他 App 的監控**。
- 沒有 macOS ESF／Endpoint Security、雲端 AI、API key、後端、PCC 自動備援。
- 不是 App Store 上架完成的保證。

## 13. 下一步需要的外部資訊

1. B 的一次完整編譯／實機結果（含第 10 節的設定資訊）。
2. A 若要擴充事件（寫檔、傳輸等），需先提供能實際收集的欄位與範例。
3. 若專題要做自動化 IR 處置，需先約定 App 內可執行的受控動作與 UI 流程，再加入執行與稽核。

## 官方參考
- [SystemLanguageModel](https://developer.apple.com/documentation/foundationmodels/systemlanguagemodel)
- [LanguageModelSession](https://developer.apple.com/documentation/foundationmodels/languagemodelsession)
- [Generating content and performing tasks with Foundation Models](https://developer.apple.com/documentation/foundationmodels/generating-content-and-performing-tasks-with-foundation-models)
- [Generating Swift data structures with guided generation](https://developer.apple.com/documentation/foundationmodels/generating-swift-data-structures-with-guided-generation)
- [GenerationOptions](https://developer.apple.com/documentation/foundationmodels/generationoptions)
- [ISO8601DateFormatter](https://developer.apple.com/documentation/foundation/iso8601dateformatter)
