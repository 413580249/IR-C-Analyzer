import Foundation

// C 模組：接收 B 提供的 [SecurityEvent]，回傳整批事件的固定規則分析結果。
// 請把本檔與既有的 SecurityEvent.swift 加入同一個 iOS App target。
// 本檔只負責規則判斷；本地 AI 說明在 LocalSecurityAI.swift，
// 模型不參與門檻、次數、狀態與風險等級的計算。
//
// 呼叫方式：
// do {
//     let result = try SecurityAnalyzer.analyze(events: collector.events)
//     print(try result.jsonString())
// } catch {
//     print(error.localizedDescription)
// }

struct SecurityAnalysisRule: Codable {
    let windowSeconds: Int
    let threshold: Int
    let comparison: String

    enum CodingKeys: String, CodingKey {
        case windowSeconds = "window_seconds"
        case threshold, comparison
    }
}

struct SecurityFinding: Codable, Identifiable {
    let ruleID: String
    let source: String
    let risk: String
    let count: Int
    let windowStart: String
    let windowEnd: String
    let reason: String
    let recommendation: String

    // 每次分析對同一來源最多產生一筆 finding，方便 B 用 ForEach 顯示。
    var id: String { "\(ruleID):\(source)" }

    enum CodingKeys: String, CodingKey {
        case ruleID = "rule_id"
        case source, risk, count
        case windowStart = "window_start"
        case windowEnd = "window_end"
        case reason, recommendation
    }
}

struct SecurityAnalysisResult: Codable {
    let status: String
    let totalEvents: Int
    let rule: SecurityAnalysisRule
    let findings: [SecurityFinding]

    enum CodingKeys: String, CodingKey {
        case status
        case totalEvents = "total_events"
        case rule, findings
    }

    // 保留你原本 result.json 的欄位名稱，可讓 B 輸出到 Console。
    // 這個方法只轉換成文字；它不會自行建立 result.json 檔案。
    func jsonString() throws -> String {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        let data = try encoder.encode(self)
        return String(decoding: data, as: UTF8.self)
    }
}

enum SecurityAnalysisError: LocalizedError {
    case invalidTimestamp(eventID: String, timestamp: String)

    var errorDescription: String? {
        switch self {
        case let .invalidTimestamp(eventID, timestamp):
            return "事件 \(eventID) 的時間格式錯誤：\(timestamp)。請使用含時區的 ISO 8601 格式，例如 2026-10-11T18:00:00+08:00。"
        }
    }
}

enum SecurityAnalyzer {
    static let windowSeconds = 60
    static let threshold = 10

    // B 的 SecurityEvent 沒有 sensitive 欄位。
    // 由專題明確指定這個檔案為「測試用敏感目標」。
    // 這是專題的測試設定，不是 iOS 自動判定檔案具有敏感性。
    static let sensitiveTargets: Set<String> = ["test_private_file.txt"]

    // 時間以「整數毫秒」比較，讓「剛好 60 秒仍計入、超過才排除」不依賴
    // Double 的捨入行為（這是預防性的加強，不是已重現的錯誤；一般情況下
    // Double 相減也會得到 60.0）。代價是毫秒以下的差異不會被區分。
    private struct TimedEvent {
        let milliseconds: Int64
        let timestamp: String
        let order: Int
    }

    static func shouldCount(_ event: SecurityEvent) -> Bool {
        event.action == "read"
            && event.result == "allowed"
            && sensitiveTargets.contains(event.target)
    }

    // 必須帶時區（Z 或 ±hh:mm），避免把本地時間誤當成 UTC。
    // B 目前產生的時間不含小數秒；也接受含小數秒的時間。
    private static func parseMilliseconds(
        _ timestamp: String,
        standard: ISO8601DateFormatter,
        fractional: ISO8601DateFormatter
    ) -> Int64? {
        let hasTimeZone = timestamp.range(
            of: "(Z|[+-][0-9]{2}:[0-9]{2})$",
            options: .regularExpression
        ) != nil
        guard hasTimeZone,
              let date = fractional.date(from: timestamp)
                ?? standard.date(from: timestamp) else {
            return nil
        }
        return Int64((date.timeIntervalSince1970 * 1000).rounded())
    }

    static func analyze(events: [SecurityEvent]) throws -> SecurityAnalysisResult {
        var grouped: [String: [TimedEvent]] = [:]

        let standardFormatter = ISO8601DateFormatter()
        standardFormatter.formatOptions = [.withInternetDateTime]
        let fractionalFormatter = ISO8601DateFormatter()
        fractionalFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]

        // 1. 只計入「成功讀取指定敏感目標」，再依來源分組。
        //    不符合計數條件的事件不解析時間，也不會因時間格式錯誤而中止。
        for (order, event) in events.enumerated() {
            guard shouldCount(event) else { continue }

            guard let milliseconds = parseMilliseconds(
                event.timestamp,
                standard: standardFormatter,
                fractional: fractionalFormatter
            ) else {
                throw SecurityAnalysisError.invalidTimestamp(
                    eventID: event.eventID,
                    timestamp: event.timestamp
                )
            }

            grouped[event.source, default: []].append(
                TimedEvent(milliseconds: milliseconds, timestamp: event.timestamp, order: order)
            )
        }

        var findings: [SecurityFinding] = []
        let windowMilliseconds = Int64(windowSeconds) * 1000

        // 2. 對每個來源找出「這批事件中，任意 60 秒內」的最大次數。
        //    不是只查看目前時間往前 60 秒；保留你原本 Python 的行為。
        //    來源依名稱排序，findings 順序因此固定且可預期。
        for source in grouped.keys.sorted() {
            guard let sourceEvents = grouped[source] else { continue }
            // 相同毫秒時以輸入順序排序，讓「相同最大峰值取先遇到的時間窗」可重現；
            // 這只影響顯示的 windowStart／windowEnd，不影響次數。
            let timestamps = sourceEvents.sorted {
                $0.milliseconds != $1.milliseconds
                    ? $0.milliseconds < $1.milliseconds
                    : $0.order < $1.order
            }
            var left = 0
            var maxCount = 0
            var peakStart: String?
            var peakEnd: String?

            for right in timestamps.indices {
                // 剛好相隔 60 秒仍包含在同一時間範圍內；超過才移出最左事件。
                while timestamps[right].milliseconds - timestamps[left].milliseconds
                    > windowMilliseconds {
                    left += 1
                }

                let count = right - left + 1
                if count > maxCount {
                    maxCount = count
                    peakStart = timestamps[left].timestamp
                    peakEnd = timestamps[right].timestamp
                }
            }

            // 3. 保留原規則的 >，而不是 >=：10 次不觸發，11 次才觸發。
            if maxCount > threshold, let start = peakStart, let end = peakEnd {
                findings.append(SecurityFinding(
                    ruleID: "sensitive_read_burst",
                    source: source,
                    risk: "medium",
                    count: maxCount,
                    windowStart: start,
                    windowEnd: end,
                    reason: "同一來源在 \(windowSeconds) 秒內，成功讀取敏感資料 \(maxCount) 次，超過設定門檻 \(threshold) 次。",
                    recommendation: "確認操作是否符合預期，並檢查相關存取紀錄。"
                ))
            }
        }

        // 模擬事件照常參與計算，才能使用 B 的測試按鈕驗證這項規則。
        // status 表示有沒有觸發本規則，不是整個 App 是否安全的判定。
        // 只能分析傳入且仍保留的事件；EventStore 的 50 筆上限仍然適用。
        return SecurityAnalysisResult(
            status: findings.isEmpty ? "no_rule_triggered" : "suspicious",
            totalEvents: events.count,
            rule: SecurityAnalysisRule(
                windowSeconds: windowSeconds,
                threshold: threshold,
                comparison: "greater_than"
            ),
            findings: findings
        )
    }
}
