import Foundation

// C 模組 v2：資料契約。模型只取得數字統計與來源代號，不取得檔案內容。
// 原本 SecurityEvent、SecurityAnalyzer 的格式與門檻保持不變。

struct SecuritySourceAlias: Codable, Equatable, Sendable, Identifiable {
    let alias: String
    let source: String
    var id: String { alias }
}

struct SecurityAIFindingFact: Codable, Equatable, Sendable {
    let sourceAlias: String
    let peakReadCount: Int
}

struct SecurityAIContext: Codable, Equatable, Sendable {
    static let maximumFindingDetails = 8

    let totalEvents: Int
    let eligibleReads: Int
    let failedReads: Int
    let excludedEvents: Int
    let simulatedEvents: Int
    let windowSeconds: Int
    let threshold: Int
    let comparison: String
    let triggeredSourceCount: Int
    let omittedFindingCount: Int
    let findingFacts: [SecurityAIFindingFact]

    static func make(events: [SecurityEvent], result: SecurityAnalysisResult) -> SecurityAIContext {
        let eligible = events.filter { SecurityAnalyzer.shouldCount($0) }.count
        let failed = events.filter { $0.action == "read" && $0.result == "failed" }.count
        let aliases = sourceAliases(for: events)
        let lookup = Dictionary(uniqueKeysWithValues: aliases.map { ($0.source, $0.alias) })
        let selected = result.findings.prefix(maximumFindingDetails)
        let facts = selected.map { finding in
            SecurityAIFindingFact(
                sourceAlias: lookup[finding.source] ?? "UNKNOWN",
                peakReadCount: finding.count
            )
        }
        return SecurityAIContext(
            totalEvents: events.count,
            eligibleReads: eligible,
            failedReads: failed,
            excludedEvents: events.count - eligible - failed,
            simulatedEvents: events.filter { $0.isSimulated }.count,
            windowSeconds: result.rule.windowSeconds,
            threshold: result.rule.threshold,
            comparison: result.rule.comparison,
            triggeredSourceCount: result.findings.count,
            omittedFindingCount: max(0, result.findings.count - facts.count),
            findingFacts: facts
        )
    }

    // 原始 source 只用在畫面與本機報告，不會放進 AI prompt。
    static func sourceAliases(for events: [SecurityEvent]) -> [SecuritySourceAlias] {
        Set(events.map { $0.source }).sorted().enumerated().map { index, source in
            SecuritySourceAlias(alias: String(format: "S%02d", index + 1), source: source)
        }
    }

    func jsonString() throws -> String {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        return String(decoding: try encoder.encode(self), as: UTF8.self)
    }
}

enum SecurityExplanationOrigin: String, Codable, Sendable {
    case onDeviceAI = "on_device_ai"
    case ruleFallback = "rule_fallback"

    var displayName: String {
        switch self {
        case .onDeviceAI: return "本地 AI 說明"
        case .ruleFallback: return "固定規則說明"
        }
    }
}

struct SecurityExplanation: Codable, Equatable, Sendable {
    let origin: SecurityExplanationOrigin
    let summary: String
    let whyItMatters: String
    let recommendedNextStep: String
    let limits: String

    // 引導生成保證資料結構；這裡另外排除空白輸出，並控制畫面長度。
    // 這不是對模型內容真實性的驗證，規則結果仍是獨立欄位。
    func validated() throws -> SecurityExplanation {
        func field(_ value: String) throws -> String {
            let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { throw SecurityAIError.invalidResponse }
            if trimmed.count > 320 {
                return String(trimmed.prefix(320)) + "…"
            }
            return trimmed
        }
        return try SecurityExplanation(
            origin: origin,
            summary: field(summary),
            whyItMatters: field(whyItMatters),
            recommendedNextStep: field(recommendedNextStep),
            limits: field(limits)
        )
    }
}

struct SecurityAIAvailability: Equatable, Sendable {
    let isAvailable: Bool
    let message: String
}

enum SecurityAIError: LocalizedError {
    case unavailable(String)
    case invalidResponse
    case generationFailed

    var errorDescription: String? {
        switch self {
        case let .unavailable(message): return message
        case .invalidResponse: return "模型輸出不完整，已改用固定規則說明。"
        case .generationFailed: return "本地模型此次未能完成說明，已保留規則結果。"
        }
    }
}

enum SecurityRuleExplanation {
    static func make(context: SecurityAIContext) -> SecurityExplanation {
        let summary: String
        let meaning: String
        let nextStep: String
        if context.totalEvents == 0 {
            summary = "目前沒有可分析的事件。"
            meaning = "沒有資料可供這項大量讀取規則判斷。"
            nextStep = "先產生或收集事件，再執行分析。"
        } else if context.triggeredSourceCount > 0 {
            summary = "這批事件有 \(context.triggeredSourceCount) 個來源觸發大量成功讀取規則。"
            meaning = "同一來源在任意 \(context.windowSeconds) 秒內的符合讀取次數超過 \(context.threshold) 次，需要確認是否符合預期。"
            nextStep = "核對是否為測試或使用者預期操作，並檢查規則結果列出的來源、次數與時間範圍。"
        } else {
            summary = "這批 \(context.totalEvents) 筆事件未觸發大量成功讀取規則。"
            meaning = "符合計數條件的成功讀取共 \(context.eligibleReads) 筆；未有來源在任意 \(context.windowSeconds) 秒內超過 \(context.threshold) 次。"
            nextStep = "保留事件紀錄；若操作行為改變，再對更新後的事件進行分析。"
        }
        return SecurityExplanation(
            origin: .ruleFallback,
            summary: summary,
            whyItMatters: meaning,
            recommendedNextStep: nextStep,
            limits: "只分析 App 提供且仍保留的事件，並非整支手機的監控。這批有 \(context.simulatedEvents) 筆模擬事件；警示不等於已確認攻擊，未觸發也不等於全面安全。"
        )
    }
}

struct SecurityIRReport: Codable, Identifiable {
    // 版本只標示「產生這份報告的程式」；報告欄位格式（schemaVersion 1.0）沒有改動，
    // 因此 2.0.0 產生的舊 reports.json 仍可直接解碼。
    static let currentModuleVersion = "2.1.0"

    let id: String
    let schemaVersion: String
    let moduleVersion: String
    let generatedAt: String
    let scope: String
    let ruleResult: SecurityAnalysisResult
    let context: SecurityAIContext
    let sourceAliases: [SecuritySourceAlias]
    let explanation: SecurityExplanation
    let explanationNotice: String?
    let events: [SecurityEvent]
    let notes: [String]

    static func make(
        events: [SecurityEvent],
        ruleResult: SecurityAnalysisResult,
        context: SecurityAIContext,
        explanation: SecurityExplanation,
        notice: String?
    ) -> SecurityIRReport {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return SecurityIRReport(
            id: UUID().uuidString,
            schemaVersion: "1.0",
            moduleVersion: currentModuleVersion,
            generatedAt: formatter.string(from: Date()),
            scope: "app_generated_events",
            ruleResult: ruleResult,
            context: context,
            sourceAliases: SecurityAIContext.sourceAliases(for: events),
            explanation: explanation,
            explanationNotice: notice,
            events: events,
            notes: [
                "規則觸發判斷由程式計算；模型僅生成說明，不修改門檻或判斷結果。",
                "目前 EventStore 預設保留 50 筆；已刪除的事件不在本次分析範圍。",
                "模型最多取得前 8 個觸發來源的精簡統計；完整 findings 保留在 ruleResult。",
                "本模組選用裝置端 SystemLanguageModel，未配置遠端模型或網路請求。"
            ]
        )
    }

    func jsonData() throws -> Data {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        return try encoder.encode(self)
    }
}
