import Foundation

#if canImport(FoundationModels)
import FoundationModels
#endif

// 每次分析建立獨立 session；沒有 API key，也沒有雲端備援呼叫。
//
// Actor 設計（刻意保持簡單一致）：
// - 協調層（SecurityExplaining、LocalSecurityAI、SecurityAnalysisViewModel、
//   SecurityReportStore）全部是 @MainActor，狀態只在主執行緒更新。
// - 規則與資料型別不加 actor 標註，只會被 MainActor 呼叫；不跨 actor 傳遞，
//   所以不需要 @unchecked Sendable 或 nonisolated(unsafe)。
// - 唯一例外是下方 @Generable 結構標成 nonisolated：若專案的
//   Default Actor Isolation 設為 MainActor，這能避免生成型別的協定
//   被推論成 MainActor 隔離。若 Xcode 對此行有意見，請把完整錯誤回傳。
@MainActor
protocol SecurityExplaining {
    var availability: SecurityAIAvailability { get }
    func explain(context: SecurityAIContext) async throws -> SecurityExplanation
}

@MainActor
final class LocalSecurityAI: SecurityExplaining {
    var availability: SecurityAIAvailability {
        #if canImport(FoundationModels)
        if #available(iOS 26.0, macOS 26.0, macCatalyst 26.0, visionOS 26.0, *) {
            switch SystemLanguageModel.default.availability {
            case .available:
                return SecurityAIAvailability(isAvailable: true, message: "本地模型可使用。")
            case .unavailable(.deviceNotEligible):
                return SecurityAIAvailability(isAvailable: false, message: "此裝置不支援 Apple Intelligence，可使用固定規則說明。")
            case .unavailable(.appleIntelligenceNotEnabled):
                return SecurityAIAvailability(isAvailable: false, message: "尚未啟用 Apple Intelligence，可使用固定規則說明。")
            case .unavailable(.modelNotReady):
                return SecurityAIAvailability(isAvailable: false, message: "本地模型尚未就緒，可能正在下載；目前可使用固定規則說明。")
            case .unavailable:
                return SecurityAIAvailability(isAvailable: false, message: "本地模型目前無法使用，可使用固定規則說明。")
            @unknown default:
                return SecurityAIAvailability(isAvailable: false, message: "本地模型狀態未知，可使用固定規則說明。")
            }
        }
        return SecurityAIAvailability(isAvailable: false, message: "本地 AI 需要 iOS 26 或更新版本；目前可使用固定規則說明。")
        #else
        return SecurityAIAvailability(isAvailable: false, message: "此 App 版本尚未提供本地模型，可使用固定規則說明。")
        #endif
    }

    func explain(context: SecurityAIContext) async throws -> SecurityExplanation {
        try Task.checkCancellation()
        let status = availability
        guard status.isAvailable else { throw SecurityAIError.unavailable(status.message) }

        #if canImport(FoundationModels)
        if #available(iOS 26.0, macOS 26.0, macCatalyst 26.0, visionOS 26.0, *) {
            return try await generate(context: context)
        }
        #endif
        throw SecurityAIError.unavailable(status.message)
    }

    #if canImport(FoundationModels)
    @available(iOS 26.0, macOS 26.0, macCatalyst 26.0, visionOS 26.0, *)
    private func generate(context: SecurityAIContext) async throws -> SecurityExplanation {
        let instructions = """
        你是 App 內事件紀錄的資安說明助手。以繁體中文、白話、簡短句子回答。
        只解釋下方程式計算好的統計，不能重新判斷是否觸發規則或改變任何數字。
        triggeredSourceCount 大於零表示本規則觸發；為零只表示本規則未觸發。
        規則是同一來源在任意 windowSeconds 秒內成功讀取指定敏感目標的次數，
        嚴格大於 threshold 才觸發；failedReads 不計入成功讀取。
        eligibleReads 是整批符合事件總數，不是單一來源在時間窗內的次數。
        findingFacts 的 peakReadCount 才是該來源某個時間窗的最大次數。
        來源是 S01 等代號。若 omittedFindingCount 大於零，部分來源細節未提供。
        事件是 App 自己提供的紀錄；不能宣稱可監控其他 App 或整支手機。
        不把模擬測試判定成真實攻擊，不宣稱中毒、已入侵或全面安全。
        不捏造網路傳輸、權限拒絕或未提供的事件；不聲稱已執行任何處置。
        建議只限核對預期操作、檢查已提供紀錄、保留紀錄與持續觀察。
        四個欄位各用一到兩句，避免列出多組數字或重複統計表。
        """
        let prompt = "請根據這份已確定的事件統計產生說明：\n" + (try context.jsonString())
        let session = LanguageModelSession(model: SystemLanguageModel.default, instructions: instructions)
        do {
            let response = try await session.respond(
                to: prompt,
                generating: GeneratedSecurityExplanation.self,
                options: GenerationOptions(temperature: 0.2)
            )
            try Task.checkCancellation()
            return try SecurityExplanation(
                origin: .onDeviceAI,
                summary: response.content.summary,
                whyItMatters: response.content.whyItMatters,
                recommendedNextStep: response.content.recommendedNextStep,
                limits: response.content.limits
            ).validated()
        } catch is CancellationError {
            throw CancellationError()
        } catch let error as SecurityAIError {
            throw error
        } catch {
            // 不把可能含 prompt 的錯誤描述寫入報告或 Console；
            // 只在 Debug 輸出錯誤型別名稱，方便 B 回報問題。
            #if DEBUG
            print("Local AI generation error type:", String(reflecting: type(of: error)))
            #endif
            throw SecurityAIError.generationFailed
        }
    }
    #endif
}

#if canImport(FoundationModels)
@available(iOS 26.0, macOS 26.0, macCatalyst 26.0, visionOS 26.0, *)
@Generable
private nonisolated struct GeneratedSecurityExplanation {
    @Guide(description: "用繁體中文，一到兩句概括已提供的規則結果。")
    var summary: String

    @Guide(description: "用繁體中文簡述這種讀取行為為何需要確認，不認定是攻擊。")
    var whyItMatters: String

    @Guide(description: "用繁體中文建議核對預期操作或保留紀錄，不聲稱已執行動作。")
    var recommendedNextStep: String

    @Guide(description: "用繁體中文說明這是 App 內事件，模擬資料與單一規則有判斷限制。")
    var limits: String
}
#endif
