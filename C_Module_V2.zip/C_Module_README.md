# C 模組第二版：規則、本地 AI 說明與報告

版本：2.0.0。這批接收目前 B 的 `[SecurityEvent]`，先由 Swift 計算規則，再用裝置端模型產生說明。模型不可用、生成失敗、取消或手動關閉 AI 時，改用固定規則說明。

**這是可交給 B 整合的程式批次，尚未在 Xcode 編譯或 iPhone 執行。** 本環境沒有 Swift／Xcode；附上的 XCTest 是待執行測試，不是通過紀錄。

## 你現在怎麼做：一次交完整批次

1. 下載並解壓縮 `C_Module_V2.zip`。
2. 打開解壓後的 `Source` 資料夾，裡面共 7 份 Swift 程式。
3. 到你自己的 GitHub 儲存庫，更新既有 `SecurityAnalyzer.swift`、`ContentView_CIntegration.swift`，並加入下面表格的 5 份新增檔案。內容以這包為準。
4. 同時更新 `C_Module_README.md`，讓 B 看得到第二版接法。
5. `Tests/SecurityModuleTests.swift` 可以一起放進 GitHub 的 Tests 資料夾；它不是 App 主程式。
6. 把這次更新的儲存庫連結交給 B，說明「C 模組第二版已整包更新，請依 README 一次整合並編譯」。如果先前只上傳到 fork，這些更新放在自己的 fork 即可；要提案給原儲存庫，再建立 Pull Request。
7. 你在 Windows 的這一批交接就完成了。接下來由 B 用 Mac 集中編譯、執行下方情境，再把錯誤文字與相關截圖一起回傳。

不必為每一份檔案分別傳訊息，也不必改一小段就測一次。整合完成後做一輪集中驗證。

## 檔案清單與 Xcode 接法

| 檔案 | 第二版處理 | 功能 |
|---|---|---|
| SecurityAnalyzer.swift | 已有第一版可保留，包內內容相同 | 固定規則、時間窗與結果 JSON |
| SecurityAIModels.swift | 新增 | AI 統計、說明來源、完整報告資料 |
| LocalSecurityAI.swift | 新增 | 裝置端 Foundation Models 與可用性檢查 |
| SecurityAnalysisViewModel.swift | 新增 | 非同步流程、取消、過期結果隔離與單批快取 |
| SecurityReportStore.swift | 新增 | 本機最多保存 10 份報告 |
| SecurityReportExporter.swift | 新增 | 準備 JSON 檔供分享或儲存 |
| ContentView_CIntegration.swift | 替換既有 ContentView.swift 的完整內容 | 主畫面、事件詳情、歷史與匯出 |

B 的操作順序：

1. 備份目前專案，或先建立一個工作分支。
2. 保留既有 `SecurityEvent.swift`、`EventCollector.swift`、`EventStore.swift`、`TestFileService.swift` 和 App 入口檔。
3. 在 Xcode 左側專案導覽列新增 C 的 6 份模組檔案（表格前 6 份）；已有 `SecurityAnalyzer.swift` 就不要重複新增。
4. 每份模組的 File Inspector → Target Membership 都勾選相同的 iOS App target。
5. 打開原本 `ContentView.swift`，把內容完整替換成 `ContentView_CIntegration.swift` 的內容。**不要把兩份含 ContentView 的檔案同時加入 App target。**
6. 原本若另外有 `EventDetailView`，也只保留一份；本包整合畫面已包含它。
7. 建議用 Xcode 26 或更新版本、iOS 26 SDK 或更新版本來編譯本地 AI 分支。畫面最低需要 iOS 16（NavigationStack、ShareLink、LabeledContent）。
8. 選擇裝置，先一次 Build；修正所有編譯錯誤後，再集中跑下方情境。
9. 要跑單元測試，再把 `Tests/SecurityModuleTests.swift` 加到 **Unit Tests target**。將第二行的 `AISecurityMonitor` 改成 App target 的 `PRODUCT_MODULE_NAME`（Build Settings 可查），然後使用 Product → Test。

`#if canImport(FoundationModels)` 讓沒有該 SDK 的版本走固定規則分支；它不代表舊裝置能執行本地 AI。現有畫面的 `#Preview` 需要支援該巨集的 Xcode。

本包依據先前提供的 B 資料契約製作；若 B 後來更名欄位、方法或型別，需一起更新呼叫端。

## 目前依賴的 B 契約

`SecurityEvent: Codable` 具有：

- `eventID, timestamp, source, action, target, result: String`
- `isSimulated: Bool`
- JSON 鍵值 `event_id`、`is_simulated`

畫面使用 `EventCollector()`、`collector.events`、`collector.$storedCount`、`clearEvents()`、`readFile(named:target:)`、`printStoredEvents()`。
檔案服務使用 `TestFileService.prepare()` 與 `TestFileService.defaultFileName`。

目前 B 的 `allowed` 代表讀檔成功，`failed` 代表讀檔出錯。它們不是權限准許／拒絕的系統稽核事件。原 Python 使用 `success` 與 `sensitive`，格式不同，不能直接代替這個 Swift 輸入。

## 規則與分析範圍

1. 只計入 `action == "read"`、`result == "allowed"`、`target == "test_private_file.txt"`。
2. 按來源分組，排序時間，找出**傳入事件中任意 60 秒內**的最大讀取次數。
3. 相隔恰好 60 秒仍計入；超過 60 秒就移出視窗。
4. 次數嚴格 **大於 10** 才觸發：10 次不觸發，11 次觸發。
5. 每個來源最多一筆 finding，風險等級固定 medium。
6. 模擬事件參與計算，以便專題展示。
7. 符合計數條件的事件必須有含時區的 ISO 8601 時間；資料錯誤時停止此次分析，不呼叫 AI。
8. 找的是保留資料中的歷史時間窗，不是現在往前 60 秒。

`test_private_file.txt` 是專題明確指定的測試用敏感目標，並非 iOS 自動分類。現有 EventStore 最多保留 50 筆，舊資料被淘汰後可能漏算。

這是 App 內事件分析；未觸發只表示這一項規則未觸發，觸發也不等於已確認攻擊。

## 本地 AI 流程

按「分析已儲存事件」後：

1. 立即計算並顯示固定規則結果。
2. 檢查 AI 開關、裝置與模型可用性。
3. 可用時建立新的 `LanguageModelSession(model: SystemLanguageModel.default)`。
4. 以 `@Generable` 的四個欄位產生摘要、如何理解、建議下一步、限制。
5. 拒絕空白欄位，裁切過長文字，保存報告。
6. 不可用或失敗就保存固定規則說明，清楚標明原因。

AI 不修改規則、風險等級、次數或觸發結果。生成的文字仍可能有誤；引導生成保證結構，不保證內容正確，畫面會提醒以規則結果為準。

AI 只取得數字統計與 S01 等來源代號，不取得原始 source、target、事件時間字串或檔案內容。最多提供前 8 個觸發來源的峰值統計，另外告知省略數；完整 findings 保存在報告。來源代號與原來源的對照只在本機畫面和報告。

這批明確使用裝置端 `SystemLanguageModel.default`，沒有配置遠端模型、API key、後端或自動網路傳送。模型資產初次準備仍可能需要下載；「本地推論」不代表初次下載不用網路。

## 裝置條件與正常備用行為

實際本地 AI 需要 iOS 26 或更新版本、支援 Apple Intelligence 的裝置、已啟用 Apple Intelligence，且模型已就緒。可用性以執行時 API 結果為準。

| 狀況 | 預期 |
|---|---|
| 未啟用 AI 開關 | 固定規則說明，不呼叫模型 |
| 系統／裝置不支援 | 固定規則說明，顯示原因 |
| Apple Intelligence 未開啟 | 固定規則說明 |
| 模型未下載完成 | 固定規則說明，可稍後重新檢查 |
| 空事件 | 不呼叫模型，保存空資料規則報告 |
| 生成失敗、模型取消或輸出空白 | 保留規則結果，使用固定規則說明 |
| 同一批事件再次分析 | 可用時重用上一份 AI 說明，避免重複推論 |
| 等待時讀取新事件／清除事件／切換 AI 開關 | 舊任務失效，不能寫回舊結果 |
| 點「停止等待 AI」或 App 進背景 | 結束畫面等待，保留固定規則報告 |

「停止等待」會取消 Swift task 並使其結果失效；不保證底層模型即刻停止。這批沒有強制推論逾時，若等候太久可使用停止按鈕。

模擬器能否使用模型要依環境確認；先用備用分支整合，再在符合條件的環境驗證真正 AI。

## 保存與匯出

- 分析歷史：Application Support／SecurityIR／reports.json，最多 10 份，最新在前。
- 與 A 的 events.json 分開保存。
- 完整報告包含：版本、時間、原始事件欄位、規則結果、精簡 AI 統計、來源代號對照、說明來源與備用原因。
- 不包含實際讀取的檔案內容。事件欄位／來源名稱仍會出現在匯出報告裡。
- 點「準備 JSON 報告」→「分享或儲存報告」，由使用者選擇去處。
- 歷史檔讀取失敗時保留原檔、不覆寫；本次結果仍能查看和匯出。使用者確認清除歷史後才能重新開始保存。
- 清除事件不清除歷史；清除歷史不清除事件。

報告外層使用 Swift property 的 camelCase；`ruleResult` 內保留第一版 snake_case 欄位，如 `total_events`、`window_seconds`。不要把整份報告當成舊 Python result.json 的完全相同格式。

## 一次集中驗證

規則情境先關閉 AI、清除事件，避免既有紀錄影響；真實 AI 情境再開啟 AI。Debug build 提供「連續讀取測試檔 11 次」。

| 情境 | 操作或輸入 | 預期結果 |
|---|---|---|
| 空資料 | 清除→分析 | 0 筆、未觸發、固定規則說明 |
| 門檻 10 | 60 秒內成功讀取 10 次→分析 | 未觸發 |
| 門檻 11 | 清除→Debug 11 次→分析 | TestApp、峰值 11、觸發 |
| 失敗不計入 | 成功 10 次＋讀取不存在檔案 1 次 | 總事件 11、未觸發 |
| 更新失效 | 分析後再讀取或清除 | 舊畫面結果清掉，需重新分析 |
| AI 不可用 | 不符合模型條件的環境分析 | 固定規則說明，有原因，無崩潰 |
| 真實 AI | 符合條件、開啟 AI→分析 | 明確標「本地 AI 說明」，規則數字正確 |
| 等待中更新／取消 | AI 生成中讀取新事件或停止等待 | 不被稍後回覆覆蓋、不持續卡在等待 |
| 快取 | 同一批事件完成後再次分析 | 使用相同批次 AI 說明，有重用提示 |
| 歷史保存 | 完成分析→關閉並重開 App | 歷史報告仍在 |
| 數量上限 | 完成 11 次不同分析 | 最多保留最近 10 份報告 |
| 匯出 | 準備並儲存 JSON，用編輯器打開 | JSON 可解析，事件、規則、說明來源一致 |

附上的 XCTest 還涵蓋：恰好／超過 60 秒、不同來源、亂序與混合時區、缺時區、AI 統計代號與 8 來源上限、空白輸出、損壞歷史保留、模型失敗／自行取消、舊回覆不得覆蓋、JSON 往返。

**驗證狀態：**已做來源與資料契約檢查、測試情境設計與壓縮包完整性檢查；Swift 編譯、XCTest、SwiftUI 操作、Foundation Models 推論與離線使用都待 B 的 Mac／裝置實際驗證。測試用假模型不證明 Apple 模型效果。

## 常見整合問題

| 錯誤或現象 | 處理 |
|---|---|
| Invalid redeclaration of ContentView／EventDetailView | 移除重複定義；整合畫面只加入一份 |
| Cannot find SecurityAnalysisViewModel 或其他型別 | 檢查所有新增檔案是否加入相同 App target |
| No such module AISecurityMonitor（測試檔） | 改為實際 PRODUCT_MODULE_NAME，確認只在 Tests target |
| 沒有本地 AI，只有固定規則 | 先看模型狀態；SDK／系統／裝置／設定未滿足時是預期行為 |
| 歷史讀取失敗 | 先匯出本次報告；舊檔保留，需要時手動清除歷史 |
| 模型文字與規則數字不同 | 以規則為準；保留報告作為集中修正 prompt 的案例 |
| SecurityEvent 第一行是 mport Foundation | 修正為 import Foundation |

## 下一個真正需要外部資訊的工作

目前可依既有 A／B 契約完成的第二版已整包提供。接下來需要：

1. B 的一次完整編譯／實機結果，確認型別、SwiftUI、SDK 與模型實際可用性。
2. A 若要擴充其他事件（寫檔、傳輸等），需先提供可實際收集的欄位與事件例子。
3. 若專題需要自動化 IR 處置，需約定 App 內可執行的受控動作與 UI 流程，再加入執行與稽核。本版只產生建議，沒有自動封鎖、刪除或阻擋行為。

不要把現階段描述成 iOS 全系統監控或已完成自動防禦。

## 官方參考

- [SystemLanguageModel：裝置端模型與可用性](https://developer.apple.com/documentation/foundationmodels/systemlanguagemodel)
- [Generating content and performing tasks](https://developer.apple.com/documentation/foundationmodels/generating-content-and-performing-tasks-with-foundation-models)
- [Generating Swift data structures with guided generation](https://developer.apple.com/documentation/foundationmodels/generating-swift-data-structures-with-guided-generation)
- [ISO8601DateFormatter](https://developer.apple.com/documentation/foundation/iso8601dateformatter)
