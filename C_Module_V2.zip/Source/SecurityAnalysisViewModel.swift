import Foundation
import Combine

// C 的完整協調流程：先計算規則，再生成說明，最後保存報告。
// 所有 UI 狀態在 MainActor 更新；資料更新會使舊 AI 任務的結果失效。
@MainActor
final class SecurityAnalysisViewModel: ObservableObject {
    @Published private(set) var ruleResult: SecurityAnalysisResult?
    @Published private(set) var explanation: SecurityExplanation?
    @Published private(set) var latestReport: SecurityIRReport?
    @Published private(set) var reports: [SecurityIRReport] = []
    @Published private(set) var isAnalyzing = false
    @Published private(set) var analysisError: String?
    @Published private(set) var explanationNotice: String?
    @Published private(set) var historyNotice: String?
    @Published private(set) var modelAvailability: SecurityAIAvailability

    private let explainer: any SecurityExplaining
    private let store: SecurityReportStore
    private var analysisTask: Task<Void, Never>?
    private var requestID: UUID?
    private var activeSnapshot: (events: [SecurityEvent], result: SecurityAnalysisResult, context: SecurityAIContext)?
    private var cachedSnapshot: Data?
    private var cachedExplanation: SecurityExplanation?

    init(explainer: (any SecurityExplaining)? = nil, store: SecurityReportStore? = nil) {
        let engine = explainer ?? LocalSecurityAI()
        let reportStore = store ?? SecurityReportStore()
        self.explainer = engine
        self.store = reportStore
        self.modelAvailability = engine.availability
        self.reports = reportStore.reports
        self.historyNotice = reportStore.loadErrorMessage
    }

    func refreshAvailability() {
        modelAvailability = explainer.availability
    }

    func invalidate() {
        analysisTask?.cancel()
        analysisTask = nil
        requestID = nil
        activeSnapshot = nil
        ruleResult = nil
        explanation = nil
        latestReport = nil
        analysisError = nil
        explanationNotice = nil
        isAnalyzing = false
    }

    func analyze(events: [SecurityEvent], useAI: Bool = true) {
        invalidate()
        refreshAvailability()
        let id = UUID()
        requestID = id
        let result: SecurityAnalysisResult
        do {
            result = try SecurityAnalyzer.analyze(events: events)
        } catch {
            analysisError = error.localizedDescription
            requestID = nil
            return
        }
        let context = SecurityAIContext.make(events: events, result: result)
        let snapshot = Self.snapshotData(events)
        activeSnapshot = (events, result, context)
        ruleResult = result

        if events.isEmpty || !useAI || !modelAvailability.isAvailable {
            let notice: String
            if events.isEmpty {
                notice = "尚無事件，本次未呼叫模型。"
            } else if !useAI {
                notice = "本次選擇只使用固定規則說明。"
            } else {
                notice = modelAvailability.message
            }
            finish(id: id, events: events, result: result, context: context,
                   explanation: SecurityRuleExplanation.make(context: context), notice: notice)
            return
        }

        if let snapshot = snapshot, snapshot == cachedSnapshot,
           let cached = cachedExplanation {
            finish(id: id, events: events, result: result, context: context,
                   explanation: cached, notice: "事件未改變，使用這批事件已有的本地 AI 說明。")
            return
        }

        isAnalyzing = true
        analysisTask = Task { @MainActor [weak self] in
            guard let self = self else { return }
            do {
                try Task.checkCancellation()
                let generated = try await self.explainer.explain(context: context)
                let validated = try generated.validated()
                try Task.checkCancellation()
                guard self.requestID == id else { return }
                if validated.origin == .onDeviceAI {
                    self.cachedSnapshot = snapshot
                    self.cachedExplanation = validated
                }
                self.finish(id: id, events: events, result: result, context: context,
                            explanation: validated, notice: nil)
            } catch is CancellationError {
                // 舊任務不能再次寫回；模型自行取消時也必須結束目前的等待。
                guard self.requestID == id else { return }
                self.finish(id: id, events: events, result: result, context: context,
                            explanation: SecurityRuleExplanation.make(context: context),
                            notice: "本地 AI 已取消此次生成，已保留固定規則說明。")
            } catch {
                guard self.requestID == id else { return }
                let notice = (error as? SecurityAIError)?.errorDescription
                    ?? "本地模型此次未能完成說明，已改用固定規則說明。"
                self.finish(id: id, events: events, result: result, context: context,
                            explanation: SecurityRuleExplanation.make(context: context), notice: notice)
            }
        }
    }

    // 若模型長時間未回應，使用者可結束等待並保留已算好的規則結果。
    // 底層模型是否立即停止依 framework 而定；此處保證舊結果不能覆蓋新畫面。
    func stopWaiting() {
        guard isAnalyzing, let active = activeSnapshot else { return }
        analysisTask?.cancel()
        analysisTask = nil
        let id = UUID()
        requestID = id
        finish(id: id, events: active.events, result: active.result, context: active.context,
               explanation: SecurityRuleExplanation.make(context: active.context),
               notice: "已結束等待本地 AI，本次保留固定規則說明。")
    }

    // 可用於批次 XCTest 或需要等待本次完整報告的呼叫端。
    func waitForCurrentAnalysis() async {
        let task = analysisTask
        await task?.value
    }

    func clearHistory() {
        do {
            try store.clear()
            reports = store.reports
            historyNotice = nil
        } catch {
            historyNotice = "歷史報告清除失敗；請稍後再試。"
        }
    }

    private func finish(
        id: UUID, events: [SecurityEvent], result: SecurityAnalysisResult,
        context: SecurityAIContext, explanation: SecurityExplanation, notice: String?
    ) {
        guard requestID == id else { return }
        self.explanation = explanation
        explanationNotice = notice
        isAnalyzing = false
        activeSnapshot = nil
        analysisTask = nil
        let report = SecurityIRReport.make(
            events: events, ruleResult: result, context: context,
            explanation: explanation, notice: notice
        )
        latestReport = report
        do {
            try store.append(report)
            reports = store.reports
            historyNotice = nil
        } catch {
            historyNotice = "歷史報告未能保存；本次分析仍可查看及匯出。"
        }
    }

    private static func snapshotData(_ events: [SecurityEvent]) -> Data? {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        return try? encoder.encode(events)
    }
}
