import Foundation
import Combine

// 【待與 A 最新 Git 檔比對】按先前公開介面重建；非 A 原始碼逐字拷貝。
@MainActor
final class EventCollector: ObservableObject {
    @Published private(set) var storedCount: Int = 0
    private let store: EventStore
    var events: [SecurityEvent] { store.events }

    init(store: EventStore = EventStore()) {
        self.store = store
        storedCount = store.events.count
    }

    func readFile(named fileName: String, target: String) {
        let result: String
        do {
            _ = try TestFileService.read(named: fileName)
            result = "allowed"
        } catch {
            result = "failed"
        }
        let event = SecurityEvent(
            eventID: store.nextEventID(), timestamp: SecurityEvent.nowTimestamp(),
            source: "TestApp", action: "read", target: target,
            result: result, isSimulated: false
        )
        store.append(event)
        storedCount = store.events.count
    }

    func readFiles(named fileNames: [String]) {
        for name in fileNames { readFile(named: name, target: name) }
    }

    func recentEvents(limit: Int) -> [SecurityEvent] { store.recentEvents(limit: limit) }
    func events(from start: Date?, to end: Date?) -> [SecurityEvent] { store.events(from: start, to: end) }

    func printStoredEvents() {
        #if DEBUG
        for event in store.events { print(event.jsonString()) }
        #endif
    }

    func clearEvents() {
        store.clear()
        storedCount = store.events.count
    }
}
