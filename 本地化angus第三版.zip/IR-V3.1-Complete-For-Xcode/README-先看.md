# IR V3.1 — Claude 風格完整 Swift 原始碼整合候選包

## 請先注意

這一包包含 **12 個 Swift 應用程式原始檔 + 1 個 XCTest 範本**，以及整合說明；**沒有 `.xcodeproj`，不是可直接開啟或發佈的完整 Xcode 專案**。B 必須把它們和目前的 Xcode 專案比較後整合，不能直接覆蓋 `main`。

### 原始碼來源與可信度

| 檔案 | 來源 |
|---|---|
| `SecurityReportStore.swift` | 使用者本次貼出的**完整原始碼**，原樣納入 |
| `SecurityReportExporter.swift` | 使用者本次貼出的**完整原始碼**，原樣納入 |
| `TestFileService.swift` | 使用者本次貼出的**完整原始碼**，原樣納入 |
| `SecurityEvent.swift` | 依先前聊天中已知資料契約**重建的相容候選版**，不是逐字還原 |
| `EventCollector.swift` | 依 A 先前描述之接口**重建的相容候選版**，不是逐字還原 |
| `EventStore.swift` | 依 A 先前描述之接口**重建的相容候選版**，不是逐字還原 |
| `SecurityAnalyzer.swift` 等 V3.1 六個原始檔 | 延續先前 V3.1 候選版；部分源自之前 Claude 改動與聊天重建，**尚未與 B/A 最新 Git 版本逐行比較** |
| `Tests/SecurityV3ContractTests.swift.template` | V3.1 測試範本（須改 module 並加到 Unit Test target） |

## 已驗證

以本機 Swift 工具鏈 `swiftc -typecheck` 成功檢查以下六檔彼此的型別相容性：
`SecurityEvent.swift`、`SecurityAnalyzer.swift`、`SecurityAIModels.swift`、`SecurityReportStore.swift`、`SecurityReportExporter.swift`、`TestFileService.swift`。

**未驗證**：iOS 專用 `Combine`、`SwiftUI`、`FoundationModels` 相關檔的完整 Xcode 編譯／Simulator／實機測試。先前 V3.1 獨立規則測試不代表本包已完成 App 整合測試。

## 本版不包括

- P1：自動觸發規則分析、自動執行 AI、新事件來源 create/write/delete、IR 處理狀態
- 完整 Xcode 專案檔、簽署設定、App 資源、原版既有測試

## 特別注意的待處理問題

1. A 的三份重建檔案必須先與 A 最新 Git 原始碼比對；A 若已有更可靠的錯誤處理、序列號與 OSLog，請以 A 版為主。
2. 目前 `EventStore` 用保留中的事件計算上次序號，App 重啟且舊資料裁切後仍可能造成 ID 重用。請列為後續修正。
3. `EventStore.append` 為保持已知接口未改 throws；檔案寫入失敗會記錄錯誤，但 UI 不會知道保存失敗，正式版本需修正。
4. `TestFileService` 的 `try?` 會略過初始化失敗，沿用使用者原始碼，請 B 在測試時留意。
5. `SecurityReportStore.clear()` 真正刪除報告，需要畫面二次確認；現有 ContentView 有確認對話框。
6. `SecurityAnalysisViewModel` 每次手動分析仍可能產生新報告；進入 P1 自動分析前要改去重／儲存策略。

下一步：B 建立分支 → 對照現有原始碼 → 單一型別只加入一份 → Build → XCTest → 實機驗證 AI。
