# CHANGELOG — V3.1 完整來源候選包

沿用 Claude 既有 V3.1 改版成果；**本次沒有擅自進行 V3.2 自動化重構**。

## 本次新增

- 原樣加入使用者提供的 `TestFileService.swift`。
- 原樣加入使用者提供的 `SecurityReportStore.swift`。
- 原樣加入使用者提供的 `SecurityReportExporter.swift`。
- 補入依先前已知介面重建的 `SecurityEvent.swift`、`EventStore.swift`、`EventCollector.swift`，全部在原始碼註明重建身份，**供 Xcode 整合比較而不是冒充 A 最新版**。
- 重新整理 README、INTEGRATION、TESTING，明確區分已檢查和待驗證項目。

## 保留 V3.1 原有的更動

- ViewModel 取消 AI 後重複保存報告的請求防護。
- 分析器跳過無效時間並記錄數量。
- 三條規則及 AI Context 多規則資訊。
- 固定規則說明、Foundation Models 提示詞。
- ContentView 除錯輸出限制、中文風險顯示。
- XCTest 範本與歷史格式相容處理。

## 尚未實作

- 真正事件自動分析、IR 狀態流程、create/write/delete 操作偵測。
- Xcode 工程編譯與實機 AI 驗證。
