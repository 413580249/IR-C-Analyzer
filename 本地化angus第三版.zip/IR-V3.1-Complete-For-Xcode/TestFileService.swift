import Foundation

enum TestFileService {//專門處理測試檔案工具箱
    static let defaultFileName = "test_private_file.txt"

    static var directory: URL {//找到這個 App 自己的 Application Support 資料夾
        FileManager.default.urls(for: .applicationSupportDirectory,
                                 in: .userDomainMask)[0]
    }

    static func fileURL(named name: String) -> URL {
        directory.appendingPathComponent(name)
    }

    // 準備測試檔案
    static func prepare() {
        try? FileManager.default.createDirectory(at: directory,
                                                 withIntermediateDirectories: true)//如果 Application Support 資料夾不存在，就建立它
        let url = fileURL(named: defaultFileName)
        if !FileManager.default.fileExists(atPath: url.path) {
            try? "secret test content".write(to: url, atomically: true, encoding: .utf8)
        }
    }

    // MARK: - 多檔案讀取測試情境（新增；不影響上面的單一檔案功能）

    /// 測試情境用的 5 個檔案：test_batch_01.txt ~ test_batch_05.txt
    static let batchFileNames: [String] = (1...5).map { String(format: "test_batch_%02d.txt", $0) }

    /// 刻意「不建立」的檔案，用來產生一筆真實的讀取失敗事件
    static let missingBatchFileName = "test_batch_missing.txt"

    /// 情境讀取順序：5 個存在的檔案，最後 1 個不存在的檔案
    static var batchScenarioFileNames: [String] { batchFileNames + [missingBatchFileName] }

    /// 準備多個測試檔案；已存在的不會覆蓋。不會建立 missingBatchFileName。
    static func prepareBatchFiles() {
        try? FileManager.default.createDirectory(at: directory,
                                                 withIntermediateDirectories: true)
        for (index, name) in batchFileNames.enumerated() {
            let url = fileURL(named: name)
            if !FileManager.default.fileExists(atPath: url.path) {
                try? "batch test content \(index + 1)".write(to: url, atomically: true, encoding: .utf8)
            }
        }
    }

    // 讀檔：成功回傳內容，失敗丟出錯誤
    static func read(named name: String) throws -> String {
        try String(contentsOf: fileURL(named: name), encoding: .utf8)
    }
}
