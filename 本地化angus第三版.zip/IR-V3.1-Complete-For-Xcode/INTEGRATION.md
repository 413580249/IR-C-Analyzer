# INTEGRATION — 給 B（Mac / Xcode）

1. 將 B 最新 Xcode 專案完整備份，新建分支 `integration/v3.1-complete`。**勿直接覆蓋 main**。
2. 先與 A 最新 Git 比對 `SecurityEvent.swift`、`EventCollector.swift`、`EventStore.swift`；本包的三個版本是按已知介面重建，若有差異，以 A 最新正確實作為基準合併，避免喪失 OSLog、保存與序號功能。
3. 本次原樣收錄 `TestFileService.swift`、`SecurityReportStore.swift`、`SecurityReportExporter.swift`，確認專案中同名型別只保留一份。
4. 合併 `SecurityAnalyzer.swift`、`SecurityAIModels.swift`、`SecurityAIInstructions.swift`、`LocalSecurityAI.swift`、`SecurityAnalysisViewModel.swift`、`ContentView.swift`。不要在同一 target 放兩份 `ContentView` 或 `SecurityAnalyzer`。
5. `SecurityAIInstructions.text` 必須由 `LocalSecurityAI` 使用；請全專案搜尋 `peakReadCount`、`SecurityAIContext(`、`SecurityAnalysisResult(`、`SecurityEvent(`、`nextEventID`，核對有無失效呼叫。
6. 將 `Tests/SecurityV3ContractTests.swift.template` 複製為 `SecurityV3ContractTests.swift`，將 `@testable import IR_App` 改為 App 的 Product Module Name；**只加入測試 target**。
7. 在 Xcode 選擇 `Product → Build`、`Product → Test`。先使用 Simulator 測試事件流程，再在符合 Apple Intelligence 資格的實機測試本地 AI。
8. 舊報告升級前請先備份本機資料；先確認讀取，切勿因版本錯誤直接清除歷史。
9. 如果失敗，保留第一個完整編譯錯誤及前後行，告知 Xcode／SDK／部署版本。

本包沒有 `.xcodeproj` 和 App Target 設定，**不能單獨打開執行**；也未完成完整 iOS Build。
