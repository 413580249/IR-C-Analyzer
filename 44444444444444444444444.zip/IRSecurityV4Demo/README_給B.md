# iOS 本地 AI IR｜第四版 Xcode 候選專案

這份專案把你在 2026-10-22 提供的 A/B Swift 快照，與 C 的第四版核心規則整合成一個 **獨立的 Xcode 專案**。不會覆蓋 B 目前可執行的原始專案。

## B 在 Mac 上只要做這些事

1. 解壓 ZIP。
2. 雙擊 `IRSecurityV4Demo.xcodeproj`。
3. 在 Xcode 上方選一台支援 iOS 26 或更新版本的模擬器。
4. 選取 **Product → Build**，成功後按 **Run**。
5. 若使用真機，先到 Signing & Capabilities 選擇自己的 Team，並設定獨立 Bundle Identifier。

### 功能與驗證

- C 規則分析：八條規則、Low / Medium / High / Critical。
- A 收集器：App 執行檔案操作時產生並儲存事件；並非跨 App 監控。
- B UI：可操作測試按鈕、分析已儲存事件、檢查報告歷史、匯出結果。
- DEBUG「模擬四級風險」是 **測試情境選擇器**：會產生對應合成事件，不能拿來證明一般事件自動分級。
- 「分析已儲存事件」使用真正 EventStore 中的事件跑規則；這與 DEBUG 模擬分開。
- 本地 AI 依 Apple Foundation Models 能否使用決定是否生成說明；不可用時保留規則結果並 fallback。

### 重要限制

- 這是根據使用者上傳的 10/22 A/B 快照製作的候選整合版，**不是 B Mac 上修改後的最新專案完整備份**。
- 建立環境不含 macOS/Xcode，因此無法在此完成 iOS Build 或真機驗證；第一次開啟請 B 回報 Xcode 最早的編譯錯誤與行號。
- 專案以 iOS 26.0 為最低部署版本以使用 Foundation Models；若 B 使用較舊的裝置或 Xcode，需要另行調整兼容方案。
- 此 App 只觀察自己的操作，不會監控其他 iPhone App，也不會自動隔離系統程序。
- 原始 zip 的 `Tests/` 是 Linux Swift 驗證工具，並非 Xcode App target；這份專案沒有直接加入它們。

