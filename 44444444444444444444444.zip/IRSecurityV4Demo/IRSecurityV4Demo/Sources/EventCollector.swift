import Foundation
import Combine

/// V3.2 新增：一次檔案操作的完整結果，讓呼叫端分得清「操作」和「記錄」各自成功與否。
struct FileOperationReport {
    let event: SecurityEvent
    let operationError: String?   // nil 代表檔案操作成功
    let recordingError: String?   // nil 代表事件已成功存檔

    var operationSucceeded: Bool { operationError == nil }
    var recordedSuccessfully: Bool { recordingError == nil }
}

// 【待與 A 最新 Git 檔比對】按先前公開介面重建；非 A 原始碼逐字拷貝。
@MainActor
final class EventCollector: ObservableObject {
    @Published private(set) var storedCount: Int = 0
    private let store: EventStore
    var events: [SecurityEvent] { store.events }

    init(store: EventStore = EventStore()) {
        self.store = store
        storedCount = store.events.count
    }

    // MARK: - 檔案操作（read / create / write / delete）
    // 共同流程（performAndRecord）：真的執行檔案操作 → 依實際結果產生一筆事件 → 存檔 → 回報給呼叫端。
    // 事件只在 performAndRecord 裡產生一次，同一次操作不會重複記錄；事件記錄失敗也不會重跑檔案操作。
    // 這是「App 自己發起的操作」的記錄，不是對 iOS 系統或其他 App 的監控。
    //
    // isSimulated 由「發起操作的測試情境」明確傳入，collector 不依操作類型自行決定。
    // 它只表示這筆事件是否屬於已定義的模擬測試情境，不代表操作是否可疑，也不是 C 的攻擊判定依據。

    /// 讀取 Application Support 根目錄的檔案（test_private_file.txt、test_batch_*.txt）。
    /// target 由呼叫端指定（C 的敏感檔規則以 target 精確比對）。現在也會回傳 FileOperationReport；
    /// 既有呼叫端不接收回傳值也能照常編譯。
    @discardableResult
    func readFile(named fileName: String, target: String, isSimulated: Bool) -> FileOperationReport {
        performAndRecord(action: "read", target: target, isSimulated: isSimulated) {
            _ = try TestFileService.read(named: fileName)
        }
    }

    @discardableResult
    func readFiles(named fileNames: [String], isSimulated: Bool) -> [FileOperationReport] {
        fileNames.map { readFile(named: $0, target: $0, isSimulated: isSimulated) }
    }

    /// 讀取 ATestSandbox 內的檔案：和 create / write / delete 是同一個位置、同一種 target。
    @discardableResult
    func readSandboxFile(named name: String, isSimulated: Bool) -> FileOperationReport {
        performAndRecord(action: "read", target: TestFileService.sandboxEventTarget(for: name),
                         isSimulated: isSimulated) {
            _ = try TestFileService.readSandboxFile(named: name)
        }
    }

    @discardableResult
    func createFile(named name: String, content: String = "A module test content",
                    isSimulated: Bool) -> FileOperationReport {
        performAndRecord(action: "create", target: TestFileService.sandboxEventTarget(for: name),
                         isSimulated: isSimulated) {
            try TestFileService.createFile(named: name, content: content)
        }
    }

    @discardableResult
    func writeFile(named name: String, content: String, isSimulated: Bool) -> FileOperationReport {
        performAndRecord(action: "write", target: TestFileService.sandboxEventTarget(for: name),
                         isSimulated: isSimulated) {
            try TestFileService.writeFile(named: name, content: content)
        }
    }

    @discardableResult
    func deleteFile(named name: String, isSimulated: Bool) -> FileOperationReport {
        performAndRecord(action: "delete", target: TestFileService.sandboxEventTarget(for: name),
                         isSimulated: isSimulated) {
            try TestFileService.deleteFile(named: name)
        }
    }

    private func performAndRecord(
        action: String, target: String, isSimulated: Bool, operation: () throws -> Void
    ) -> FileOperationReport {
        // 1. 真的執行檔案操作，成功或失敗都要記錄。
        var operationError: String?
        do { try operation() } catch { operationError = error.localizedDescription }

        // 2. 依實際結果產生事件。
        let event = SecurityEvent(
            eventID: store.nextEventID(), timestamp: SecurityEvent.nowTimestamp(),
            source: "TestApp", action: action, target: target,
            result: operationError == nil ? "allowed" : "failed",
            isSimulated: isSimulated
        )

        // 3. 存檔；存檔失敗不能被吞掉，要回報給呼叫端。檔案操作的成敗不受存檔結果影響。
        var recordingError: String?
        do { try store.appendChecked(event) } catch {
            recordingError = error.localizedDescription
            NSLog("EventCollector: 事件存檔失敗 %@", String(describing: error))
        }
        storedCount = store.events.count

        return FileOperationReport(event: event, operationError: operationError,
                                   recordingError: recordingError)
    }

    func recentEvents(limit: Int) -> [SecurityEvent] { store.recentEvents(limit: limit) }
    func events(from start: Date?, to end: Date?) -> [SecurityEvent] { store.events(from: start, to: end) }

    func printStoredEvents() {
        #if DEBUG
        for event in store.events { print(event.jsonString()) }
        #endif
    }

    func clearEvents() {
        store.clear()
        storedCount = store.events.count
    }
}
