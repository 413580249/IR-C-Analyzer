import Foundation

// 以公開 c-analyzer-v2 分支中已核對的資料結構與規則重建。
// 原始版本：https://github.com/413580249/IR-C-Analyzer/blob/c-analyzer-v2/SecurityAnalyzer.swift
// 使用前務必與該分支最新提交比對；請勿與另一份 SecurityAnalyzer.swift 同時加入 target。
struct SecurityAnalysisRule: Codable {
    let windowSeconds: Int
    let threshold: Int
    let comparison: String
    enum CodingKeys: String, CodingKey {
        case windowSeconds = "window_seconds"
        case threshold, comparison
    }
}

struct SecurityFinding: Codable, Identifiable {
    let ruleID: String
    let source: String
    let risk: String
    let count: Int
    let windowStart: String
    let windowEnd: String
    let reason: String
    let recommendation: String
    // V4: audit-friendly evidence. Older JSON reports decode without these fields.
    let evidenceEventIDs: [String]
    let evidenceConfidence: String
    var id: String { "\(ruleID):\(source)" }
    init(ruleID: String, source: String, risk: String, count: Int, windowStart: String,
         windowEnd: String, reason: String, recommendation: String,
         evidenceEventIDs: [String] = [], evidenceConfidence: String = "limited") {
        self.ruleID = ruleID; self.source = source; self.risk = risk; self.count = count
        self.windowStart = windowStart; self.windowEnd = windowEnd
        self.reason = reason; self.recommendation = recommendation
        self.evidenceEventIDs = evidenceEventIDs; self.evidenceConfidence = evidenceConfidence
    }
    enum CodingKeys: String, CodingKey {
        case ruleID = "rule_id"
        case source, risk, count
        case windowStart = "window_start", windowEnd = "window_end"
        case reason, recommendation
        case evidenceEventIDs = "evidence_event_ids", evidenceConfidence = "evidence_confidence"
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        ruleID = try c.decode(String.self, forKey: .ruleID)
        source = try c.decode(String.self, forKey: .source)
        risk = try c.decode(String.self, forKey: .risk)
        count = try c.decode(Int.self, forKey: .count)
        windowStart = try c.decode(String.self, forKey: .windowStart)
        windowEnd = try c.decode(String.self, forKey: .windowEnd)
        reason = try c.decode(String.self, forKey: .reason)
        recommendation = try c.decode(String.self, forKey: .recommendation)
        evidenceEventIDs = try c.decodeIfPresent([String].self, forKey: .evidenceEventIDs) ?? []
        evidenceConfidence = try c.decodeIfPresent(String.self, forKey: .evidenceConfidence) ?? "unknown"
    }
}

struct SecurityAnalysisResult: Codable {
    let status: String
    let totalEvents: Int
    let rule: SecurityAnalysisRule
    let findings: [SecurityFinding]
    // V3.1: malformed timestamps are skipped, not interpreted as valid evidence.
    let invalidTimestampCount: Int
    init(status: String, totalEvents: Int, rule: SecurityAnalysisRule,
         findings: [SecurityFinding], invalidTimestampCount: Int = 0) {
        self.status = status
        self.totalEvents = totalEvents
        self.rule = rule
        self.findings = findings
        self.invalidTimestampCount = invalidTimestampCount
    }
    enum CodingKeys: String, CodingKey {
        case status
        case totalEvents = "total_events"
        case rule, findings
        case invalidTimestampCount = "invalid_timestamp_count"
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        status = try c.decode(String.self, forKey: .status)
        totalEvents = try c.decode(Int.self, forKey: .totalEvents)
        rule = try c.decode(SecurityAnalysisRule.self, forKey: .rule)
        findings = try c.decode([SecurityFinding].self, forKey: .findings)
        invalidTimestampCount = try c.decodeIfPresent(Int.self, forKey: .invalidTimestampCount) ?? 0
    }
    func jsonString() throws -> String {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        return String(decoding: try encoder.encode(self), as: UTF8.self)
    }
}

enum SecurityAnalysisError: LocalizedError {
    case invalidTimestamp(eventID: String, timestamp: String)
    var errorDescription: String? {
        switch self {
        case let .invalidTimestamp(eventID, timestamp):
            return "事件 \(eventID) 的時間格式錯誤：\(timestamp)。請使用含時區的 ISO 8601 格式。"
        }
    }
}

// V4: only externally verified/app-defined classification; never infer sensitivity from arbitrary names.
enum SecurityTargetClassification: String, Codable {
    case unknown, publicData, internalData, sensitive, critical
}

struct SecurityAnalysisPolicy {
    var targetClassification: [String: SecurityTargetClassification] = [:]
    // Existing demo allowlist is included for backward compatibility only.
    func classification(for target: String) -> SecurityTargetClassification {
        if let value = targetClassification[target] { return value }
        return target == "test_private_file.txt" ? .sensitive : .unknown
    }
}

enum SecurityAnalyzer {
    static let windowSeconds = 60
    static let threshold = 10
    static let sensitiveTargets: Set<String> = ["test_private_file.txt"] // legacy API
    static let multiFileThreshold = 5
    static let failedReadThreshold = 5
    static let mutationThreshold = 5
    private struct TimedEvent {
        let event: SecurityEvent
        let date: Date
    }
    private struct Peak {
        let events: [TimedEvent]
        let value: Int
        var start: String { events.first?.event.timestamp ?? "" }
        var end: String { events.last?.event.timestamp ?? "" }
        var ids: [String] { events.map { $0.event.eventID } }
    }
    private static func parseDate(_ event: SecurityEvent) -> Date? {
        guard event.timestamp.range(of: "(Z|[+-][0-9]{2}:[0-9]{2})$", options: .regularExpression) != nil else { return nil }
        let simple = ISO8601DateFormatter()
        simple.formatOptions = [.withInternetDateTime]
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return fractional.date(from: event.timestamp) ?? simple.date(from: event.timestamp)
    }
    static func shouldCount(_ event: SecurityEvent) -> Bool {
        event.action == "read" && event.result == "allowed" && sensitiveTargets.contains(event.target)
    }
    private static func isSensitive(_ target: String, _ policy: SecurityAnalysisPolicy) -> Bool {
        let classification = policy.classification(for: target)
        return classification == .sensitive || classification == .critical
    }
    // Deterministic 60s sliding window with the actual subset of contributing event IDs.
    private static func peak(_ input: [TimedEvent], score: ([TimedEvent]) -> Int) -> Peak? {
        guard !input.isEmpty else { return nil }
        let sorted = input.sorted { $0.date == $1.date ? $0.event.eventID < $1.event.eventID : $0.date < $1.date }
        var left = 0
        var winner: Peak?
        for right in sorted.indices {
            while sorted[right].date.timeIntervalSince(sorted[left].date) > Double(windowSeconds) { left += 1 }
            let subset = Array(sorted[left...right])
            let value = score(subset)
            if value > (winner?.value ?? 0) { winner = Peak(events: subset, value: value) }
        }
        return winner
    }
    static func analyze(events: [SecurityEvent], policy: SecurityAnalysisPolicy = SecurityAnalysisPolicy()) throws -> SecurityAnalysisResult {
        var groups: [String: [TimedEvent]] = [:]
        var invalid = 0
        for event in events {
            guard let date = parseDate(event) else { invalid += 1; continue }
            // Unknown operation/result is retained in original reports but does not become risk evidence.
            guard ["read", "create", "write", "delete"].contains(event.action),
                  ["allowed", "failed"].contains(event.result) else { continue }
            groups[event.source, default: []].append(TimedEvent(event: event, date: date))
        }
        var findings: [SecurityFinding] = []
        func add(_ rule: String, _ source: String, _ risk: String, _ count: Int,
                 _ evidence: [TimedEvent], _ reason: String, _ recommendation: String) {
            guard let first = evidence.first, let last = evidence.last else { return }
            findings.append(SecurityFinding(ruleID: rule, source: source, risk: risk,
                count: count, windowStart: first.event.timestamp, windowEnd: last.event.timestamp,
                reason: reason, recommendation: recommendation,
                evidenceEventIDs: evidence.map { $0.event.eventID },
                evidenceConfidence: evidence.allSatisfy { $0.event.isSimulated } ? "simulated" :
                  (evidence.contains { $0.event.isSimulated } ? "mixed" : "event_observed")))
        }
        for source in groups.keys.sorted() {
            let sorted = (groups[source] ?? []).sorted { $0.date == $1.date ? $0.event.eventID < $1.event.eventID : $0.date < $1.date }
            let sensitiveReads = sorted.filter { $0.event.action == "read" && $0.event.result == "allowed" && isSensitive($0.event.target, policy) }
            if let p = peak(sensitiveReads, score: { $0.count }), p.value > threshold {
                add("sensitive_read_burst", source, p.value >= 20 ? "high" : "medium", p.value, p.events,
                    "60 秒內成功讀取已標記敏感目標 \(p.value) 次；異常頻率不代表外洩。", "核對操作用途、比對正常頻率並保留紀錄。")
            }
            let reads = sorted.filter { $0.event.action == "read" && $0.event.result == "allowed" }
            // The evidence MUST contain distinct target representatives; not unrelated repetitions.
            if let p = peak(reads, score: { Set($0.map { $0.event.target }).count }), p.value >= multiFileThreshold {
                var seen = Set<String>()
                let representatives = p.events.filter { seen.insert($0.event.target).inserted }
                add("multi_file_read", source, "medium", p.value, representatives,
                    "60 秒內成功讀取 \(p.value) 個不同目標；尚不能判定是否不當存取。", "檢查批次讀取是否符合預期。")
            }
            let failed = sorted.filter { $0.event.action == "read" && $0.event.result == "failed" }
            if let p = peak(failed, score: { $0.count }), p.value >= failedReadThreshold {
                add("repeated_read_failure", source, "low", p.value, p.events,
                    "60 秒內讀取失敗 \(p.value) 次；可能是權限、路徑或重試問題。", "查核目標存在性、權限與重試設定。")
            }
            let creations = sorted.filter { $0.event.action == "create" && $0.event.result == "allowed" }
            if let p = peak(creations, score: { $0.count }), p.value >= 5 {
                add("repeated_file_creation", source, "low", p.value, p.events,
                    "60 秒內成功建立 \(p.value) 個檔案；可能是正常批次建立或測試行為。",
                    "核對批次工作用途、建立檔案的預期數量及來源。")
            }
            let mutations = sorted.filter { ["write", "delete"].contains($0.event.action) && $0.event.result == "allowed" }
            for action in ["write", "delete"] {
                let matches = mutations.filter { $0.event.action == action && isSensitive($0.event.target, policy) }
                if !matches.isEmpty {
                    // One finding per source/rule, with all matching evidence, not falsely labeled 60-second peak.
                    let risk = matches.contains { policy.classification(for: $0.event.target) == .critical } ? "critical" : "high"
                    add(action == "write" ? "sensitive_file_write" : "sensitive_file_delete",
                        source, risk, matches.count, matches,
                        "已記錄 \(matches.count) 次成功\(action == "write" ? "寫入" : "刪除")已分類敏感目標；未驗證修改內容或授權狀態。",
                        "保留檔案與操作證據，核對授權、備份與復原需求；由管理者決定處置。")
                }
            }
            if let p = peak(mutations, score: { $0.count }), p.value >= mutationThreshold {
                add("repeated_file_mutation", source, "medium", p.value, p.events,
                    "60 秒內成功修改或刪除 \(p.value) 次；不代表惡意。", "核對例行批次作業、版本紀錄和備份。")
            }
            // Aggregate chain severity over all true ordered pairs, not just the first one.
            var chains: [(TimedEvent, TimedEvent, String)] = []
            for mutation in mutations {
                guard let read = reads.last(where: {
                    $0.event.target == mutation.event.target && $0.date <= mutation.date &&
                    mutation.date.timeIntervalSince($0.date) <= Double(windowSeconds)
                }) else { continue }
                let sensitive = isSensitive(mutation.event.target, policy)
                let recentSensitiveReads = sensitiveReads.filter {
                    $0.event.target == mutation.event.target && $0.date <= mutation.date &&
                    mutation.date.timeIntervalSince($0.date) <= Double(windowSeconds)
                }.count
                let classification = policy.classification(for: mutation.event.target)
                let severity = classification == .critical || (sensitive && mutation.event.action == "delete" && recentSensitiveReads > threshold)
                    ? "critical" : (sensitive ? "high" : "medium")
                chains.append((read, mutation, severity))
            }
            if let strongest = chains.max(by: { severityRank($0.2) < severityRank($1.2) }) {
                let evidence = [strongest.0, strongest.1]
                add("read_then_mutate", source, strongest.2, 2, evidence,
                    "60 秒內同來源對同一目標先成功讀取，再成功\(strongest.1.event.action == "delete" ? "刪除" : "修改")；依已知分類與關聯行為估計風險，不代表確認入侵。",
                    "核對操作是否授權；保留事件及備份，交由人工評估後續限制或復原。")
            }
        }
        findings.sort { $0.source == $1.source ? $0.ruleID < $1.ruleID : $0.source < $1.source }
        return SecurityAnalysisResult(status: findings.isEmpty ? "no_rule_triggered" : "suspicious",
            totalEvents: events.count, rule: SecurityAnalysisRule(windowSeconds: windowSeconds,
            threshold: threshold, comparison: "greater_than"), findings: findings,
            invalidTimestampCount: invalid)
    }
    private static func severityRank(_ risk: String) -> Int {
        switch risk { case "critical": return 4; case "high": return 3; case "medium": return 2; default: return 1 }
    }
}
