import Foundation

/// A completely in-memory demonstration. Does NOT touch the filesystem or append to EventStore.
/// Build this only into a testing/demo target or expose it behind #if DEBUG in the UI.
enum SecurityDemoScenario: String, CaseIterable, Identifiable {
    case low = "Low｜連續讀取失敗"
    case medium = "Medium｜敏感檔大量讀取"
    case high = "High｜更頻繁的敏感讀取"
    case critical = "Critical｜大量讀取後刪除"
    var id: String { rawValue }
    var events: [SecurityEvent] {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        let base = Date().addingTimeInterval(-40)
        func make(_ i: Int, _ action: String, _ target: String, _ outcome: String = "allowed") -> SecurityEvent {
            SecurityEvent(eventID: "DEMO-\(i + 1)",
                timestamp: formatter.string(from: base.addingTimeInterval(Double(i))),
                source: "DEMO-ONLY", action: action, target: target, result: outcome, isSimulated: true)
        }
        switch self {
        case .low: return (0..<5).map { make($0, "read", "missing_demo_file.txt", "failed") }
        case .medium: return (0..<11).map { make($0, "read", "test_private_file.txt") }
        case .high: return (0..<20).map { make($0, "read", "test_private_file.txt") }
        case .critical:
            return (0..<11).map { make($0, "read", "test_private_file.txt") } +
                [make(11, "delete", "test_private_file.txt")]
        }
    }
}
