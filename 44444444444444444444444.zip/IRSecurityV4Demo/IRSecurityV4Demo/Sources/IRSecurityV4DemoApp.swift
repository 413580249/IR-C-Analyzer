import SwiftUI

@main
struct IRSecurityV4DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

